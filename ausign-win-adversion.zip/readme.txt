1.对windows10这种权限要求严格的，请右击后选择  使用管理员权限运行kxsign_gui.exe,
  win7可以直接双击运行
2.linux 和mac如果使用命令行版本直接运行kxsign，不需要安装其他工具和软件
如果使用界面版本kxsign_gui.jar 需要安装java jre 8 或者jdk 8以上版本 下载地址 www.java.com/download
3.kxsign.exe是命令行版本，kxsign_gui是界面版本，界面版本需要有命令行版本才能运行，命令行版本不需要其他任何文件就可以运行
4.软件不支持32位操作系统
5.可以加群648474103了解及时动态，那样可以常上官网http://s.kxapp.com下载最新版本

